Diya Kulkarni  
2440482  
[dkulkarni@chapman.edu](mailto:dkulkarni@chapman.edu)  
CPSC-392-01  
Assignment 1

Runtime Errors:

- Had issues with the dummy variables as well as the z-scoring continuous variables. It should be good by now but it was something I ran into often.

References:

- Logistic Regression Notes  
- TTSRidgeLassoNotes  
- Python Stuff to Know Notes  
- [https://scikit-learn.org/stable/modules/generated/sklearn.preprocessing.PolynomialFeatures.html](https://scikit-learn.org/stable/modules/generated/sklearn.preprocessing.PolynomialFeatures.html)  
- Data Visualization Notes  
- Professor Hansen